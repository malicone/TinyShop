<?php

namespace NovaPoshta_example;


class Test_example
{
    public static function test()
    {



    }
}
