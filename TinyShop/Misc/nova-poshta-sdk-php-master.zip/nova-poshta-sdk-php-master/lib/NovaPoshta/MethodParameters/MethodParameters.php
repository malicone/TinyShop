<?php

namespace NovaPoshta\MethodParameters;

use NovaPoshta\Core\BaseModel;

/**
 * Использовать для передачи параметров в методы моделей
 *
 * Class MethodParameters
 * @package NovaPoshta\MethodParameters
 */
class MethodParameters extends BaseModel
{

}